import firebase from 'firebase';
 var firebaseConfig = {
    apiKey: "AIzaSyBD_atsTPsTwT52jiwuwDVZYIaPywPVkCk",
    authDomain: "login-55a9e.firebaseapp.com",
    projectId: "login-55a9e",
    storageBucket: "login-55a9e.appspot.com",
    messagingSenderId: "249273897742",
    appId: "1:249273897742:web:4ba06b888ddc1a40aabd5f"
  };
  
  const fire = firebase.initializeApp(firebaseConfig);

  export default fire;