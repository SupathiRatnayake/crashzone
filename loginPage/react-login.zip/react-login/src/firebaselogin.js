import firebase from 'firebase';
 // Your web app's Firebase configuration
 var firebaseConfig = {
  apiKey: "AIzaSyBzEHACemu3skdZDKQ0C7Rj1yUA8Q7SoiU",
  authDomain: "user-login-66303.firebaseapp.com",
  projectId: "user-login-66303",
  storageBucket: "user-login-66303.appspot.com",
  messagingSenderId: "694269638491",
  appId: "1:694269638491:web:d5326f37e6ac9a44f8cc7e"
};
  
  const fire = firebase.initializeApp(firebaseConfig);

  export default fire;